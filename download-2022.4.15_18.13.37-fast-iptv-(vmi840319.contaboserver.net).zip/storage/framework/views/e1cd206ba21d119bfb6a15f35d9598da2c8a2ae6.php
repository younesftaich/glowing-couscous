<!DOCTYPE html>
<html>
  <head>
    <title>Luxury Premium Service</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <link href="<?php echo e(mix('/css/app.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(mix('/js/app.js')); ?>" defer></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="2a9863ff-a31c-4bf6-8bed-69e2a6f23472";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-KS321FD4C6"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KS321FD4C6');
</script>
  </head>
  <body style = "font-family: 'Poppins', sans-serif;">
    <div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div>
  </body>
</html><?php /**PATH /home/luxuryiptv/public_html/resources/views/app.blade.php ENDPATH**/ ?>