<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Post2Controller extends Controller
{
    //
}
