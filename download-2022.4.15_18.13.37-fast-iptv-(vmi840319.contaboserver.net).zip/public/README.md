MailWizz - Email marketing application.  
========
    
INSTALL STEPS: https://kb.mailwizz.com/articles/install-steps/  
(Follow these only if you install a fresh copy of the app)  

__  

GETTING STARTED STEPS: https://kb.mailwizz.com/article-categories/getting-started/    
(Follow these only if you are new to using the app)  
  
__  
      
UPGRADE STEPS: https://kb.mailwizz.com/articles/upgrade-steps/  
(Follow these only if you upgrade the app)  

__  

As always, you can get more info from www.mailwizz.com website.  
If you get stuck, please use the website to contact me.  
Thank you.  
 